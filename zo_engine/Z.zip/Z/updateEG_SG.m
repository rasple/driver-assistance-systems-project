function [ EG, SG ] = updateEG_SG( CvIn, ChIn, LIn, LvLIn, mIn)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

g = 9.81;
Cv = CvIn;
Ch = ChIn;
L = LIn;
Lv_L = LvLIn;
Lh = L - Lv_L*L;
m = mIn;

Cv_stern = L*Cv/(g*m*Lh);
Ch_stern = L*Ch/(g*m*Lv);

EG = 1/g * (1/Cv_stern - 1/Ch_stern);
SG = 1/(g * Ch_stern);
end

